<?php

/* 
 *footer for website
 */

?>


<footer>    <div class="footer">        <div class="container">            <div class="footer-wrapper">                <div class="row">														<div class="col-md-3 col-sm-3 footer-col">							<div class="footer-content">								<div class="footer-content-logo">                                                                        <img src="http://www.wef.org.in/wp-content/uploads/2016/09/wef-1.png" title="Women Economic Forum" class="logo wef" />               									<!--<img src="http://www.wef.org.in/wp-content/themes/weblizar/images/web-logo.png" alt=""/>-->								</div>								<div class="footer-content-text">									<p>The Women Economic Forum is a place for ordinary women to seek to rise to extraordinary heights.A place for dreamers and achievers to learn and explore. A place for living life to its fullest while embracing personal growth. A place to love and care and contribute to societal upliftment.</p>								</div>							</div>						</div>						
<div class="col-md-3 col-sm-3 footer-col">							
<div class="footer-title">Contact</div>	
<div class="footer-content">
<div class="footer-posts">
<ul class="posts-list">										

<li>
<!--<div class="posts-list-thumbnail"><a href="">													
<img src="http://www.wef.org.in/wp-content/themes/weblizar/image/team/babita-1.jpg" alt="" width="50px"/></a>											
</div>	-->
<div class="posts-list-content">
<a href="" class="posts-list-title">Babita Pandita </a>
<span class="posts-list-meta"><a href="mailto:babita.pandita@wef.org.in">babita.pandita@wef.org.in</a></span></div>
</li>

<!--
<li><div class="posts-list-thumbnail">
<a href=""><img src="http://www.wef.org.in/wp-content/themes/weblizar/image/team/mag1.jpg" alt="" width="50px"/></a></div><div class="posts-list-content">												<a href="" class="posts-list-title">Magdalena Sieradzka  </a><span class="posts-list-meta"><a href="mailto:magdalena.sieradzka@wef.org.in"> magdalena.sieradzka@wef.org.in</a>												</span></div>
</li> -->

<!--<li>
<div class="posts-list-thumbnail">
<a href="">
<img src="http://www.wef.org.in/wp-content/themes/weblizar/image/team/laurie1.jpg" alt="" width="50px"/>
</a>
</div>
<div class="posts-list-content">
<a href="" class="posts-list-title">Laurie A Baum </a>
<span class="posts-list-meta">
<a href="mailto:laurie.baum@wef.org.in"> laurie.baum@wef.org.in</a>
</span>	
</div>
</li>-->

<li>
<!--
<div class="posts-list-thumbnail">
<a href="">
<img src="http://www.wef.org.in/wp-content/themes/weblizar/image/team/meenakshi.jpg" alt="" width="50px"/>
</a>
</div>
-->
<div class="posts-list-content">
<a href="" class="posts-list-title">Nikita Aggarwal  </a>
<span class="posts-list-meta">
<a href="mailto:nikita.agarwal@aall.in"> nikita.agarwal@aall.in</a>
</span>
</div>
</li>

</ul>
</div>
</div>
</div>

                    					
<div class="col-md-3 col-sm-3 footer-col">
 <div class="footer-title">Get In Touch	</div>	
 <div class="footer-content">
  <ul class="contact-info"><li>		
  <div class="contact-title"><i class="fa fa-map-marker"></i>Address</div>	
    <div class="contact-details">B-II/66, MCIE, First Floor, Mathura Road,New Delhi</div></li>
<!--									<li>										<div class="contact-title">											<i class="fa fa-mobile"></i>phone										</div>										<div class="contact-details">123-345-6666</div>									</li>-->	
      <li>
          <div class="contact-title"><i class="fa fa-envelope"></i>eMail</div>
          <div class="contact-details"><a href="mailto:info@wef.org.in">info@wef.org.in</a></div>	
      </li>
      <li>
      <div class="contact-title">
          <i class="fa fa-globe"></i>Website</div>
          <div class="contact-details"><a href="http://www.wef.org.in/">www.wef.org.in</a></div>
          </li>
          
      <li>
      <div class="contact-title">
          <i class="fa fa-globe"></i>Disclaimer</div>
          <div class="contact-details"><a href="http://www.wef.org.in/disclaimer-condi/" target="_blank">Disclaimer</a></div>
          </li>    
  </ul>							</div>						</div>																								<div class="col-md-3 col-sm-3 footer-col">							<div class="footer-title">								Some other Links							</div>							<div class="footer-content">                                                                                                                        <ul class="contact-info">									<li>										<div class="contact-title">											<i class="fa fa-globe"></i>E-book										</div>									<div class="contact-details"><a href="http://www.wef.org.in/ALL-WEF%202015%20Book.pdf">E-book</a></div>									</li>									<li>										<div class="contact-title">											<i class="fa fa-globe"></i>WEF Gallery										</div>										<div class="contact-details"><a href="http://www.wef.org.in/wef-2015/">WEF-Gallery</a></div>									</li>									<li>										<div class="contact-title">											<i class="fa fa-globe"></i>Contact Us										</div>										<div class="contact-details"><a href="http://www.wef.org.in/contact-us/">Contact Us</a></div>									</li>

<li>										<div class="contact-title">											<i class="fa fa-globe"></i>FAQ’S										</div>										<div class="contact-details"><a href="http://www.wef.org.in/faqs/">FAQ’S</a></div>									</li>

																	</ul>                                                           
						</div>						</div>								                </div>			            </div>        </div>        <div class="copyright">            <div class="container">                <div class="row">				                    <div class="col-md-6 col-sm-6">                        <div class="copyright-text">© 2014 ALL LADIES LEAGUE							<a  rel="nofollow" href="http://www.wef.org.in/" target="_blank">														</a>						</div>                    </div>					                    <div class="col-md-6 col-sm-6"> 						<div class="social-icons">							<ul>																<li><a href="https://www.facebook.com/WomenEcoForum" title="facebook" target="_blank" class="social-media-icon facebook-icon">Facebook</a></li>																<li><a href="https://twitter.com/WomenEcoForum" title="twitter" target="_blank" class="social-media-icon twitter-icon">Twitter</a></li>																<li><a href="https://plus.google.com/+ALLWomenEconomicForumNewDelhi" title="googleplus" target="_blank" class="social-media-icon googleplus-icon">Googleplus</a></li>																<li><a href="https://www.linkedin.com/company/all-women-economic-forum" title="linkedin" target="_blank" class="social-media-icon linkedin-icon">Linkedin</a></li>															</ul>						</div>                    </div>					                </div>            </div>        </div>					<style type="text/css">					</style>		   <span id="blog_count" style="display:none;">3 ,</span> </div>    </footer>
