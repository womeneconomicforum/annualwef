<?php

/*
 * For header portion of the website page
 * 
 */

?>

<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="WEF &raquo; Feed" href="http://www.wef.org.in/feed/" />
<link rel="alternate" type="application/rss+xml" title="WEF &raquo; Comments Feed" href="http://www.wef.org.in/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/www.wef.org.in\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.6.3"}};
			!function(a,b,c){function d(a){var c,d,e,f,g,h=b.createElement("canvas"),i=h.getContext&&h.getContext("2d"),j=String.fromCharCode;if(!i||!i.fillText)return!1;switch(i.textBaseline="top",i.font="600 32px Arial",a){case"flag":return i.fillText(j(55356,56806,55356,56826),0,0),!(h.toDataURL().length<3e3)&&(i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,65039,8205,55356,57096),0,0),c=h.toDataURL(),i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,55356,57096),0,0),d=h.toDataURL(),c!==d);case"diversity":return i.fillText(j(55356,57221),0,0),e=i.getImageData(16,16,1,1).data,f=e[0]+","+e[1]+","+e[2]+","+e[3],i.fillText(j(55356,57221,55356,57343),0,0),e=i.getImageData(16,16,1,1).data,g=e[0]+","+e[1]+","+e[2]+","+e[3],f!==g;case"simple":return i.fillText(j(55357,56835),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode8":return i.fillText(j(55356,57135),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode9":return i.fillText(j(55358,56631),0,0),0!==i.getImageData(16,16,1,1).data[0]}return!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i;for(i=Array("simple","flag","unicode8","diversity","unicode9"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='cuar.frontend-css'  href='http://www.wef.org.in/wp-content/plugins/customer-area/skins/frontend/master/assets/css/styles.min.css?ver=7.0.8' type='text/css' media='all' />
<link rel='stylesheet' id='bne-testimonial-styles-css'  href='http://www.wef.org.in/wp-content/plugins/bne-testimonials/assets/css/bne-testimonials.css?ver=1.7.5' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='http://www.wef.org.in/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.5.1' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='http://www.wef.org.in/wp-content/plugins/js_composer/assets/lib/bower/font-awesome/css/font-awesome.min.css?ver=4.5.2' type='text/css' media='screen' />
<link rel='stylesheet' id='wpdm-bootstrap-css'  href='http://www.wef.org.in/wp-content/plugins/download-manager/assets/bootstrap/css/bootstrap.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='wpdm-front-css'  href='http://www.wef.org.in/wp-content/plugins/download-manager/assets/css/front.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='drawit-css-css'  href='http://www.wef.org.in/wp-content/plugins/drawit/css/drawit.min.css?ver=1.1.0' type='text/css' media='all' />
<link rel='stylesheet' id='easy-facebook-likebox-plugin-styles-css'  href='http://www.wef.org.in/wp-content/plugins/easy-facebook-likebox/public/assets/css/public.css?ver=4.2.6' type='text/css' media='all' />
<link rel='stylesheet' id='easy-facebook-likebox-popup-styles-css'  href='http://www.wef.org.in/wp-content/plugins/easy-facebook-likebox/public/assets/popup/magnific-popup.css?ver=4.2.6' type='text/css' media='all' />
<link rel='stylesheet' id='bwg_frontend-css'  href='http://www.wef.org.in/wp-content/plugins/photo-gallery/css/bwg_frontend.css?ver=1.3.18' type='text/css' media='all' />
<link rel='stylesheet' id='bwg_sumoselect-css'  href='http://www.wef.org.in/wp-content/plugins/photo-gallery/css/sumoselect.css?ver=1.3.18' type='text/css' media='all' />
<link rel='stylesheet' id='bwg_font-awesome-css'  href='http://www.wef.org.in/wp-content/plugins/photo-gallery/css/font-awesome/font-awesome.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='bwg_mCustomScrollbar-css'  href='http://www.wef.org.in/wp-content/plugins/photo-gallery/css/jquery.mCustomScrollbar.css?ver=1.3.18' type='text/css' media='all' />
<link rel='stylesheet' id='bwg_googlefonts_0-css'  href='https://fonts.googleapis.com/css?family=ABeeZee|Abel|Abril+Fatface|Aclonica|Acme|Actor|Adamina|Advent+Pro|Aguafina+Script|Akronim|Aladin|Aldrich|Alef|Alegreya|Alegreya+SC|Alegreya+Sans|Alex+Brush|Alfa+Slab+One|Alice|Alike|Alike+Angular|Allan|Allerta|Allerta+Stencil|Allura|Almendra|Almendra+Display|Almendra+SC|Amarante|Amaranth|Amatic+SC|Amethysta|Amiri|Amita|Anaheim|Andada|Andika|Angkor|Annie+Use+Your+Telescope|Anonymous+Pro|Antic|Antic+Didone|Antic+Slab|Anton|Arapey|Arbutus|Arbutus+Slab|Architects+Daughter|Archivo+Black|Archivo+Narrow|Arimo|Arizonia|Armata|Artifika|Arvo|Arya|Asap|Asar|Asset|Astloch|Asul|Atomic+Age|Aubrey|Audiowide|Autour+One|Average|Average+Sans|Averia+Gruesa+Libre|Averia+Libre|Averia+Sans+Libre|Averia+Serif+Libre|Bad+Script|Balthazar|Bangers|Basic|Battambang|Baumans|Bayon|Belgrano|BenchNine|Bentham|Berkshire+Swash|Bevan|Bigelow+Rules|Bigshot+One|Bilbo|Bilbo+Swash+Caps|Biryani|Bitter|Black+Ops+One|Bokor|Bonbon|Boogaloo|Bowlby+One|Bowlby+One+SC|Brawler|Bree+Serif|Bubblegum+Sans|Bubbler+One|Buda|Buda+Light+300|Buenard|Butcherman|Butterfly+Kids|Cabin|Cabin+Condensed|Cabin+Sketch|Caesar+Dressing|Cagliostro|Calligraffitti|Cambay|Cambo|Candal|Cantarell|Cantata+One|Cantora+One|Capriola|Cardo|Carme|Carrois+Gothic|Carrois+Gothic+SC|Carter+One|Caudex|Caveat+Brush|Cedarville+Cursive|Ceviche+One|Changa+One|Chango|Chau+Philomene+One|Chela+One|Chelsea+Market|Chenla|Cherry+Cream+Soda|Chewy|Chicle|Chivo|Chonburi|Cinzel|Cinzel+Decorative|Clicker+Script|Coda|Coda+Caption|Codystar|Combo|Comfortaa|Coming+Soon|Concert+One|Condiment|Content|Contrail+One&#038;subset=greek,latin,greek-ext,vietnamese,cyrillic-ext,latin-ext,cyrillic' type='text/css' media='all' />
<link rel='stylesheet' id='bwg_googlefonts_150-css'  href='https://fonts.googleapis.com/css?family=Convergence|Cookie|Copse|Corben|Courgette|Cousine|Coustard|Covered+By+Your+Grace|Crafty+Girls|Creepster|Crete+Round|Crimson+Text|Croissant+One|Crushed|Cuprum|Cutive|Cutive+Mono|Damion|Dancing+Script|Dangrek|Dawning+of+a+New+Day|Days+One|Dekko|Delius|Delius+Swash+Caps|Delius+Unicase|Della+Respira|Denk+One|Devonshire|Dhurjati|Didact+Gothic|Diplomata|Diplomata+SC|Domine|Donegal+One|Doppio+One|Dorsa|Dosis|Dr+Sugiyama|Droid+Sans|Droid+Sans+Mono|Droid+Serif|Duru+Sans|Dynalight|EB+Garamond|Eagle+Lake|Eater|Economica|Eczar|Ek+Mukta|Electrolize|Elsie|Elsie+Swash+Caps|Emblema+One|Emilys+Candy|Engagement|Englebert|Enriqueta|Erica+One|Esteban|Euphoria+Script|Ewert|Exo|Exo+2|Expletus+Sans|Fanwood+Text|Fascinate|Fascinate+Inline|Faster+One|Fasthand|Fauna+One|Federant|Federo|Felipa|Fenix|Finger+Paint|Fira+Mono|Fjalla+One|Fjord+One|Flamenco|Flavors|Fondamento|Fontdiner+Swanky|Forum|Francois+One|Freckle+Face|Fredericka+the+Great|Fredoka+One|Freehand|Fresca|Frijole|Fruktur|Fugaz+One|GFS+Didot|GFS+Neohellenic|Gabriela|Gafata|Galdeano|Galindo|Gentium+Basic|Gentium+Book+Basic|Geo|Geostar|Geostar+Fill|Germania+One|Gidugu|Gilda+Display|Give+You+Glory|Glass+Antiqua|Glegoo|Gloria+Hallelujah|Goblin+One|Gochi+Hand|Gorditas|Goudy+Bookletter+1911|Graduate|Grand+Hotel|Gravitas+One|Great+Vibes|Griffy|Gruppo|Gudea|Gurajada|Habibi|Halant|Hammersmith+One|Hanalei|Hanalei+Fill|Handlee|Hanuman|Happy+Monkey|Headland+One|Henny+Penny|Herr+Von+Muellerhoff|Hind|Holtwood+One+SC|Homemade+Apple|Homenaje|IM+Fell+DW+Pica|IM+Fell+DW+Pica+SC|IM+Fell+Double+Pica|IM+Fell+Double+Pica+SC|IM+Fell+English|IM+Fell+English+SC|IM+Fell+French+Canon|IM+Fell+French+Canon+SC|IM+Fell+Great+Primer|IM+Fell+Great+Primer+SC|Iceberg|Iceland&#038;subset=greek,latin,greek-ext,vietnamese,cyrillic-ext,latin-ext,cyrillic' type='text/css' media='all' />
<link rel='stylesheet' id='bwg_googlefonts_300-css'  href='https://fonts.googleapis.com/css?family=Imprima|Inconsolata|Inder|Indie+Flower|Inika|Inknut+Antiqua|Irish+Grover|Istok+Web|Italiana|Italianno|Itim|Jacques+Francois|Jacques+Francois+Shadow|Jaldi|Jim+Nightshade|Jockey+One|Jolly+Lodger|Josefin+Sans|Josefin+Slab|Joti+One|Judson|Julee|Julius+Sans+One|Junge|Jura|Just+Another+Hand|Just+Me+Again+Down+Here|Kadwa|Kameron|Kanit|Karla|Kaushan+Script|Kavoon|Keania+One|Kelly+Slab|Kenia|Khand|Khmer|Khula|Kite+One|Knewave|Kotta+One|Koulen|Kranky|Kreon|Kristi|Krona+One|Kurale|La+Belle+Aurore|Laila|Lakki+Reddy|Lancelot|Lateef|Lato|League+Script|Leckerli+One|Ledger|Lekton|Lemon|Libre+Baskerville|Life+Savers|Lilita+One|Lily+Script+One|Limelight|Linden+Hill|Lobster|Lobster+Two|Londrina+Outline|Londrina+Shadow|Londrina+Sketch|Londrina+Solid|Lora|Love+Ya+Like+A+Sister|Loved+by+the+King|Lovers+Quarrel|Luckiest+Guy|Lusitana|Lustria|Macondo|Macondo+Swash+Caps|Magra|Maiden+Orange|Mako|Mandali|Marcellus|Marcellus+SC|Marck+Script|Margarine|Marko+One|Marmelad|Martel|Martel+Sans|Marvel|Mate|Mate+SC|Maven+Pro|McLaren|Meddon|MedievalSharp|Medula+One|Megrim|Meie+Script|Merienda|Merienda+One|Merriweather|Merriweather+Sans|Metal|Metal+Mania|Metamorphous|Metrophobic|Michroma|Milonga|Miltonian|Miltonian+Tattoo|Miniver|Miss+Fajardose|Modak|Modern+Antiqua|Molengo|Molle:400i|Monda|Monofett|Monoton|Monsieur+La+Doulaise|Montaga|Montez|Montserrat|Montserrat+Alternates|Montserrat+Subrayada|Moul|Moulpali|Mountains+of+Christmas|Mouse+Memoirs|Mr+Bedfort|Mr+Dafoe|Mr+De+Haviland|Mrs+Saint+Delafield|Mrs+Sheppards|Muli|Mystery+Quest|NTR|Neucha|Neuton|New+Rocker|News+Cycle|Niconne|Nixie+One|Nobile|Nokora|Norican&#038;subset=greek,latin,greek-ext,vietnamese,cyrillic-ext,latin-ext,cyrillic' type='text/css' media='all' />
<link rel='stylesheet' id='bwg_googlefonts_450-css'  href='https://fonts.googleapis.com/css?family=Nosifer|Nothing+You+Could+Do|Noticia+Text|Noto+Sans|Noto+Serif|Nova+Cut|Nova+Flat|Nova+Mono|Nova+Oval|Nova+Round|Nova+Script|Nova+Slim|Nova+Square|Numans|Nunito|Odor+Mean+Chey|Offside|Old+Standard+TT|Oldenburg|Oleo+Script|Oleo+Script+Swash+Caps|Open+Sans|Open+Sans+Condensed:300|Oranienbaum|Orbitron|Oregano|Orienta|Original+Surfer|Oswald|Over+the+Rainbow|Overlock|Overlock+SC|Ovo|Oxygen|Oxygen+Mono|PT+Mono|PT+Sans|PT+Sans+Caption|PT+Sans+Narrow|PT+Serif|PT+Serif+Caption|Pacifico|Palanquin|Palanquin+Dark|Paprika|Parisienne|Passero+One|Passion+One|Pathway+Gothic+One|Patrick+Hand|Patrick+Hand+SC|Patua+One|Paytone+One|Peddana|Peralta|Permanent+Marker|Petit+Formal+Script|Petrona|Philosopher|Piedra|Pinyon+Script|Pirata+One|Plaster|Play|Playball|Playfair+Display|Playfair+Display+SC|Podkova|Poiret+One|Poller+One|Poly|Pompiere|Pontano+Sans|Poppins|Port+Lligat+Sans|Port+Lligat+Slab|Pragati+Narrow|Prata|Preahvihear|Press+Start+2P|Princess+Sofia|Prociono|Prosto+One|Puritan|Purple+Purse|Quando|Quantico|Quattrocento|Quattrocento+Sans|Questrial|Quicksand|Quintessential|Qwigley|Racing+Sans+One|Radley|Rajdhani|Raleway|Raleway+Dots|Ramabhadra|Ramaraja|Rambla|Rammetto+One|Ranchers|Rancho|Ranga|Rationale|Ravi+Prakash|Redressed|Reenie+Beanie|Revalia|Rhodium+Libre|Ribeye|Ribeye+Marrow|Righteous|Risque|Roboto|Roboto+Condensed|Roboto+Mono|Roboto+Slab|Rochester|Rock+Salt|Rokkitt|Romanesco|Ropa+Sans|Rosario|Rosarivo|Rouge+Script|Rozha+One|Rubik|Rubik+Mono+One|Rubik+One|Ruda|Rufina|Ruge+Boogie|Ruluko|Rum+Raisin|Ruslan+Display|Russo+One|Ruthie|Rye|Sacramento|Sahitya|Sail|Salsa|Sanchez|Sancreek|Sansita+One|Sarina|Sarpanch|Satisfy&#038;subset=greek,latin,greek-ext,vietnamese,cyrillic-ext,latin-ext,cyrillic' type='text/css' media='all' />
<link rel='stylesheet' id='bwg_googlefonts_600-css'  href='https://fonts.googleapis.com/css?family=Scada|Schoolbell|Seaweed+Script|Sevillana|Seymour+One|Shadows+Into+Light|Shadows+Into+Light+Two|Shanti|Share|Share+Tech|Share+Tech+Mono|Shojumaru|Short+Stack|Siemreap|Sigmar+One|Signika|Signika+Negative|Simonetta|Sintony|Sirin+Stencil|Six+Caps|Skranji|Slabo+13px|Slackey|Smokum|Smythe|Sniglet|Snippet|Snowburst+One|Sofadi+One|Sofia|Sonsie+One|Sorts+Mill+Goudy|Source+Code+Pro|Source+Sans+Pro|Source+Serif+Pro|Special+Elite|Spicy+Rice|Spinnaker|Spirax|Squada+One|Sree+Krushnadevaraya|Stalemate|Stalinist+One|Stardos+Stencil|Stint+Ultra+Condensed|Stint+Ultra+Expanded|Stoke|Strait|Sue+Ellen+Francisco|Sumana|Sunshiney|Supermercado+One|Sura|Suranna|Suravaram|Suwannaphum|Swanky+and+Moo+Moo|Syncopate|Tangerine|Taprom|Tauri|Teko|Telex|Tenali+Ramakrishna|Tenor+Sans|Text+Me+One|The+Girl+Next+Door|Tienne|Tillana|Timmana|Tinos|Titan+One|Titillium+Web|Trade+Winds|Trocchi|Trochut|Trykker|Tulpen+One|Ubuntu|Ubuntu+Condensed|Ubuntu+Mono|Ultra|Uncial+Antiqua|Underdog|Unica+One|UnifrakturCook:700|UnifrakturMaguntia|Unkempt|Unlock|Unna|VT323|Vampiro+One|Varela|Varela+Round|Vast+Shadow|Vibur|Vidaloka|Viga|Voces|Volkhov|Vollkorn|Voltaire|Waiting+for+the+Sunrise|Wallpoet|Walter+Turncoat|Warnes|Wellfleet|Wendy+One|Wire+One|Work+Sans|Yanone+Kaffeesatz|Yantramanav|Yellowtail|Yeseva+One|Yesteryear|Zeyada&#038;subset=greek,latin,greek-ext,vietnamese,cyrillic-ext,latin-ext,cyrillic' type='text/css' media='all' />
<link rel='stylesheet' id='portfolio-all-css-css'  href='http://www.wef.org.in/wp-content/plugins/portfolio-gallery/style/portfolio-all.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='style2-os-css-css'  href='http://www.wef.org.in/wp-content/plugins/portfolio-gallery/style/style2-os.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='lightbox-css-css'  href='http://www.wef.org.in/wp-content/plugins/portfolio-gallery/style/lightbox.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-min-css-css'  href='http://www.wef.org.in/wp-content/themes/weblizar/css/font-awesome-4.5.0/css/font-awesome.min.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-min-css'  href='http://www.wef.org.in/wp-content/themes/weblizar/css/bootstrap.min.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='responsive-css'  href='http://www.wef.org.in/wp-content/themes/weblizar/css/responsive.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='flat-blue-css'  href='http://www.wef.org.in/wp-content/themes/weblizar/css/skins/flat-blue.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='theme-menu-css'  href='http://www.wef.org.in/wp-content/themes/weblizar/css/theme-menu.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='carousel-css'  href='http://www.wef.org.in/wp-content/themes/weblizar/css/carousel.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='wpdreams-asl-basic-css'  href='http://www.wef.org.in/wp-content/plugins/ajax-search-lite/css/style.basic.css?ver=4.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='wpdreams-ajaxsearchlite-css'  href='http://www.wef.org.in/wp-content/plugins/ajax-search-lite/css/style-classic-blue.css?ver=4.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_custom_css-css'  href='//www.wef.org.in/wp-content/uploads/js_composer/custom.css?ver=4.5.2' type='text/css' media='screen' />
<link rel='stylesheet' id='rtbs-css'  href='http://www.wef.org.in/wp-content/plugins/responsive-tabs/css/rtbs_style.min.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='__EPYT__style-css'  href='http://www.wef.org.in/wp-content/plugins/youtube-embed-plus/styles/ytprefs.min.css?ver=4.6.3' type='text/css' media='all' />
<style id='__EPYT__style-inline-css' type='text/css'>

                .epyt-gallery-thumb {
                        width: 33.333%;
                }
</style>
<link rel='stylesheet' id='wp-booklet-dark-css'  href='http://www.wef.org.in/wp-content/plugins/wp-booklet/themes/booklet/dark/booklet.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='wp-booklet-light-css'  href='http://www.wef.org.in/wp-content/plugins/wp-booklet/themes/booklet/light/booklet.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='fancybox-css'  href='http://www.wef.org.in/wp-content/plugins/easy-fancybox/fancybox/jquery.fancybox-1.3.7.min.css?ver=1.5.7' type='text/css' media='screen' />
<link rel='stylesheet' id='wl-style-css'  href='http://www.wef.org.in/wp-content/plugins/while-it-is-loading/css/wl-style.css?ver=4.6.3' type='text/css' media='all' />
<script type='text/javascript' src='http://www.wef.org.in/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/download-manager/assets/bootstrap/js/bootstrap.min.js?ver=4.6.3'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/download-manager/assets/js/front.js?ver=4.6.3'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/download-manager/assets/js/chosen.jquery.min.js?ver=4.6.3'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/easy-facebook-likebox/public/assets/popup/jquery.magnific-popup.min.js?ver=4.2.6'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/easy-facebook-likebox/public/assets/js/jquery.cookie.js?ver=4.2.6'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/easy-facebook-likebox/public/assets/js/public.js?ver=4.2.6'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/photo-gallery/js/bwg_frontend.js?ver=1.3.18'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var bwg_objectsL10n = {"bwg_select_tag":"Select Tag."};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/photo-gallery/js/jquery.sumoselect.min.js?ver=1.3.18'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/photo-gallery/js/jquery.mobile.js?ver=1.3.18'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/photo-gallery/js/jquery.mCustomScrollbar.concat.min.js?ver=1.3.18'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/photo-gallery/js/jquery.fullscreen-0.4.1.js?ver=0.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var bwg_objectL10n = {"bwg_field_required":"field is required.","bwg_mail_validation":"This is not a valid email address.","bwg_search_result":"There are no images matching your search."};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/photo-gallery/js/bwg_gallery_box.js?ver=1.3.18'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/themes/weblizar/js/menu/menu.js?ver=4.6.3'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/themes/weblizar/js/bootstrap.js?ver=4.6.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var load_more_posts_var = {"counts":"1","blog_count":"3"};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/themes/weblizar/js/more-posts.js?ver=4.6.3'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/responsive-tabs/js/rtbs.min.js?ver=4.6.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _EPYT_ = {"ajaxurl":"http:\/\/www.wef.org.in\/wp-admin\/admin-ajax.php","security":"196e937da9","gallery_scrolloffset":"20","eppathtoscripts":"http:\/\/www.wef.org.in\/wp-content\/plugins\/youtube-embed-plus\/scripts\/","epresponsiveselector":"[\"iframe[src*='youtube.com']\",\"iframe[src*='youtube-nocookie.com']\",\"iframe[data-ep-src*='youtube.com']\",\"iframe[data-ep-src*='youtube-nocookie.com']\",\"iframe[data-ep-gallerysrc*='youtube.com']\"]","epdovol":"1","version":"11.4","evselector":"iframe.__youtube_prefs__[src], iframe[src*=\"youtube.com\/embed\/\"], iframe[src*=\"youtube-nocookie.com\/embed\/\"]"};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/youtube-embed-plus/scripts/ytprefs.min.js?ver=4.6.3'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/wp-booklet/assets/js/jquery.wpbooklet.js?ver=4.6.3'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/wp-booklet/assets/js/jquery.wpbookletcarousel.js?ver=4.6.3'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/wp-booklet/assets/js/jquery.wpbooklet-image-popup.min.js?ver=4.6.3'></script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/wp-booklet/assets/js/jquery.wpbooklet-extended.js?ver=4.6.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var quicktagsL10n = {"closeAllOpenTags":"Close all open tags","closeTags":"close tags","enterURL":"Enter the URL","enterImageURL":"Enter the URL of the image","enterImageDescription":"Enter a description of the image","textdirection":"text direction","toggleTextdirection":"Toggle Editor Text Direction","dfw":"Distraction-free writing mode","strong":"Bold","strongClose":"Close bold tag","em":"Italic","emClose":"Close italic tag","link":"Insert link","blockquote":"Blockquote","blockquoteClose":"Close blockquote tag","del":"Deleted text (strikethrough)","delClose":"Close deleted text tag","ins":"Inserted text","insClose":"Close inserted text tag","image":"Insert image","ul":"Bulleted list","ulClose":"Close bulleted list tag","ol":"Numbered list","olClose":"Close numbered list tag","li":"List item","liClose":"Close list item tag","code":"Code","codeClose":"Close code tag","more":"Insert Read More tag"};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.wef.org.in/wp-includes/js/quicktags.min.js?ver=4.6.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var drawitFE = {"mediaupload":"http:\/\/www.wef.org.in\/wp-admin\/\/media-upload.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.wef.org.in/wp-content/plugins/drawit/js/qt-btn.js?ver=1.1.0'></script>
<meta name="generator" content="WordPress Download Manager 2.9.0" />
<link rel='https://api.w.org/' href='http://www.wef.org.in/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://www.wef.org.in/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://www.wef.org.in/wp-includes/wlwmanifest.xml" /> 
<link rel='shortlink' href='http://www.wef.org.in/?p=15966' />
<link rel="alternate" type="application/json+oembed" href="http://www.wef.org.in/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwww.wef.org.in%2Fannual-wef-new-delhi-may-8-13th-2017%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://www.wef.org.in/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwww.wef.org.in%2Fannual-wef-new-delhi-may-8-13th-2017%2F&#038;format=xml" />
<meta name="generator" content="Custom Login v3.2.5" />

        <script>
            var wpdm_site_url = 'http://www.wef.org.in/';
            var wpdm_home_url = 'http://www.wef.org.in/';
            var ajax_url = 'http://www.wef.org.in/wp-admin/admin-ajax.php';
        </script>


        			<script>
			function desvanecer(){
				var pic = document.getElementById('display');
				if(pic != null){
					pic.style.opacity -= 0.03;
					if(pic.style.opacity < 0.0)
						pic.parentNode.removeChild(pic);
					else
						setTimeout(function(){desvanecer()},30);
				}
			}
			setTimeout(function(){if(document.getElementById('display') != null)desvanecer();},9999);
			window.addEventListener('load',desvanecer);
			</script>
		                <link href='//fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
                <!-- All in one Favicon 4.3 --><link rel="shortcut icon" href="http://www.wef.org.in/wp-content/uploads/2016/06/favicon.ico" />
<meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="http://www.wef.org.in/wp-content/plugins/js_composer/assets/css/vc-ie8.css" media="screen"><![endif]-->                <style type="text/css">
                    <!--
                    
            @font-face {
                font-family: 'aslsicons2';
                src: url('//www.wef.org.in/wp-content/plugins/ajax-search-lite/css/fonts/icons2.eot');
                src: url('//www.wef.org.in/wp-content/plugins/ajax-search-lite/css/fonts/icons2.eot?#iefix') format('embedded-opentype'),
                     url('//www.wef.org.in/wp-content/plugins/ajax-search-lite/css/fonts/icons2.woff2') format('woff2'),
                     url('//www.wef.org.in/wp-content/plugins/ajax-search-lite/css/fonts/icons2.woff') format('woff'),
                     url('//www.wef.org.in/wp-content/plugins/ajax-search-lite/css/fonts/icons2.ttf') format('truetype'),
                     url('//www.wef.org.in/wp-content/plugins/ajax-search-lite/css/fonts/icons2.svg#icons') format('svg');
                font-weight: normal;
                font-style: normal;
            }
            div[id*='ajaxsearchlite'].wpdreams_asl_container {
                width: 100%;
                margin: 0px 0px 0px 0px;
            }
            div[id*='ajaxsearchliteres'].wpdreams_asl_results div.resdrg span.highlighted {
                font-weight: bold;
                color: rgba(217, 49, 43, 1);
                background-color: rgba(238, 238, 238, 1);
            }
            div[id*='ajaxsearchliteres'].wpdreams_asl_results .results div.asl_image {
                width: 70px;
                height: 70px;
            }
                                -->
                </style>
                            <script type="text/javascript">
                if ( typeof _ASL !== "undefined" && _ASL !== null && typeof _ASL.initialize !== "undefined" )
                    _ASL.initialize();
            </script>
            
<!-- Easy FancyBox 1.5.7 using FancyBox 1.3.7 - RavanH (http://status301.net/wordpress-plugins/easy-fancybox/) -->
<script type="text/javascript">
/* <![CDATA[ */
var fb_timeout = null;
var fb_opts = { 'overlayShow' : true, 'hideOnOverlayClick' : true, 'showCloseButton' : true, 'centerOnScroll' : true, 'enableEscapeButton' : true, 'autoScale' : true };
var easy_fancybox_handler = function(){
	/* IMG */
	jQuery('a.fancybox, area.fancybox, li.fancybox a:not(li.nofancybox a)').fancybox( jQuery.extend({}, fb_opts, { 'transitionIn' : 'elastic', 'easingIn' : 'easeOutBack', 'transitionOut' : 'elastic', 'easingOut' : 'easeInBack', 'opacity' : false, 'hideOnContentClick' : false, 'titleShow' : true, 'titlePosition' : 'over', 'titleFromAlt' : true, 'showNavArrows' : true, 'enableKeyboardNav' : true, 'cyclic' : false }) );
}
/* ]]> */
</script>
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>
<body class="page page-id-15966 page-template page-template-page-fullwidth page-template-page-fullwidth-php customer-area-active wpb-js-composer js-comp-ver-4.5.2 vc_responsive"  >
<div id="menu_wrapper" >
	<div class="top_wrapper">
		<header id="header">
			<div class="row">
				<nav class="navbar navbar-default" role="navigation">
					<div class="container-fluid">						
					<div class="col-md-3">
						<div class="navbar-header" id="navbar-header">						  
						  <div class="logo pull-left">							
							<a title="Weblizar" href="http://www.wef.org.in/">
														<img src="http://www.wef.org.in/wp-content/uploads/2016/09/wef-1.png" style="height:105px; width:105px;" />
														</a>					
						  </div>
						  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						  </button>
						</div>
					</div>
					<div class="col-md-9">
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						  <ul id="menu-main-menu" class="nav navbar-nav navbar-left"><li id="menu-item-12" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12"><a title="Home" href="http://www.wef.org.in/">Home</a></li>
<li id="menu-item-19511" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19511"><a title="About Us" href="http://www.wef.org.in/about-us/">About Us</a></li>
<li id="menu-item-19507" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-15966 current_page_item menu-item-19507 active"><a title="Annual WEF" href="http://www.wef.org.in/annual-wef-new-delhi-may-8-13th-2017/">Annual WEF</a></li>
<li id="menu-item-19508" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19508"><a title="WEF Worldwide" href="http://www.wef.org.in/wef-worldwide/">WEF Worldwide</a></li>
<li id="menu-item-19525" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-19525"><a title="Awards" href="http://www.womenofthedecade.org/">Awards</a></li>
<li id="menu-item-21462" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21462"><a title="Testimonials" href="http://www.wef.org.in/testimonial/">Testimonials</a></li>
<li id="menu-item-19527" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19527"><a title="Past WEF" href="http://www.wef.org.in/past-wef-events/">Past WEF</a></li>
<li id="menu-item-19509" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19509"><a title="Contact Us" href="http://www.wef.org.in/contact-us/">Contact Us</a></li>
<li id="menu-item-19523" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-19523"><a title="&lt;img src=&quot;http://www.wef.org.in/wp-content/uploads/2016/12/ja.jpg&quot; title=&quot;ALL Ladies League&quot; style=&quot;width:120px;margin-top:-5px;&quot;&gt;" href="http://www.aall.in/"><img src="http://www.wef.org.in/wp-content/uploads/2016/12/ja.jpg" title="ALL Ladies League" style="width:120px;margin-top:-5px;"></a></li>
</ul>						</div>
					</div>
					</div>
				</nav>		
			</div>
		</header>
	</div>
</div>
    
    
<!--<div class="space-sep20"></div>-->
<!--<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 949645523;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/949645523/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>-->
